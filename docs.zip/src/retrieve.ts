import { pool } from "./db.js";
import { embed } from "./embed.js";

export type Chunk = {
  content: string;
  source: string;
  score: number;
};

const TOP_K = 4;
const MIN_SCORE = 0.5;

export async function retrieve(question: string): Promise<Chunk[]> {
  const questionVector = await embed(question);

  const { rows } = await pool.query<Chunk>(
    `SELECT content, source, 1 - (embedding <=> $1::vector) AS score
     FROM documents
     ORDER BY embedding <=> $1::vector
     LIMIT $2`,
    [JSON.stringify(questionVector), TOP_K],
  );

  // keep only chunks that are actually related
  return rows
    .map((r) => ({ ...r, score: Number(r.score) }))
    .filter((r) => r.score >= MIN_SCORE);
}