import express from "express";
import { retrieve } from "./retrieve.js";

const app = express();
app.use(express.json());

type OllamaStreamPart = {
  message?: { content: string };
  done: boolean;
};

app.post("/ask", async (req, res) => {
  const question = req.body?.question;

  // 1. Validate input
  if (typeof question !== "string" || question.trim() === "") {
    res.status(400).json({ error: "question is required" });
    return;
  }

  // 2. RETRIEVE
  const chunks = await retrieve(question);

  res.setHeader("Content-Type", "text/plain; charset=utf-8");

  // Nothing relevant → answer directly, no AI call
  if (chunks.length === 0) {
    res.end("I don't know, please contact support.");
    return;
  }

  // 3. AUGMENT
  const context = chunks.map((c) => `- [${c.source}] ${c.content}`).join("\n");

  // 4. GENERATE, with streaming turned on
  const ollamaRes = await fetch("http://localhost:11434/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "llama3.2:3b",
      messages: [
        {
          role: "system",
          content: `You are a support assistant for a payment company.
Answer using ONLY the documents below. Keep the answer short.
If the documents only answer part of the question, say what is missing.
If nothing in the documents is related to the question, say: "I don't know, please contact support."

DOCUMENTS:
${context}`,
        },
        { role: "user", content: question },
      ],
      stream: true, // 🆕 Ollama sends the answer piece by piece
      options: { temperature: 0 },
    }),
  });

  if (!ollamaRes.ok || !ollamaRes.body) {
    res.status(502).end("AI service error");
    return;
  }

  // 5. Read Ollama's stream and pass each piece to the client
  const reader = ollamaRes.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? ""; // keep any half-received line for next time

    for (const line of lines) {
      if (!line.trim()) continue;
      const part = JSON.parse(line) as OllamaStreamPart;
      if (part.message?.content) {
        res.write(part.message.content); // send this piece to the client now
      }
    }
  }

  // 6. Add the sources at the end
  const sources = [...new Set(chunks.map((c) => c.source))].join(", ");
  res.end(`\n\nSources: ${sources}`);
});

app.listen(3000, () => {
  console.log("RAG API running on http://localhost:3000");
});