import { retrieve, type Chunk } from "./retrieve.js";

const REFUSAL = "I don't know, please contact support.";

type OllamaChatResponse = {
  message: { content: string };
};

export async function answer(question: string): Promise<{ text: string; chunks: Chunk[] }> {
  // 1. RETRIEVE
  const chunks = await retrieve(question);
  if (chunks.length === 0) {
    return { text: REFUSAL, chunks };
  }

  // 2. AUGMENT
  const context = chunks.map((c) => `- [${c.source}] ${c.content}`).join("\n");

  // 3. GENERATE
  const res = await fetch("http://localhost:11434/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "llama3.2:3b",
      messages: [
        {
          role: "system",
          content: `You are a support assistant for a payment company.
Answer using ONLY the documents below. Keep the answer short.
If the documents only answer part of the question, say what is missing.
If nothing in the documents is related to the question, say: "${REFUSAL}"

DOCUMENTS:
${context}`,
        },
        { role: "user", content: question },
      ],
      stream: false,
      options: { temperature: 0 },
    }),
  });

  const data: OllamaChatResponse = await res.json();
  return { text: data.message.content, chunks };
}