import { pool } from "../src/db.js";
import { retrieve } from "../src/retrieve.js";

const chunks = await retrieve("Why is my merchant payout stuck?");

for (const c of chunks) {
  console.log(c.score.toFixed(3), `[${c.source}]`, c.content);
}

await pool.end();